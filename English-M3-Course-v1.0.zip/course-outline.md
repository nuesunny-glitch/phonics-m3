# Course Outline: English M.3 Course
### แผนการเรียนภาษาอังกฤษ ม.3 (พื้นฐานต่ำมาก → พร้อมสอบเข้า ม.4)

เอกสารนี้สรุปภาพรวมทั้งคอร์ส ลำดับการเรียน และสถานะความคืบหน้าของแต่ละบท
**ทุกบททำเสร็จครบแล้วทั้ง 15 บท** — เปิดเรียนได้ทันทีที่ [`index.html`](./index.html)

## ภาพรวมคอร์ส (Course Map)

```
พื้นฐานการอ่าน               ไวยากรณ์หลัก                  ทักษะรวม/สอบ
(Decoding Foundation)       (Core Grammar)                (Integration/Exam)
─────────────────────      ─────────────────────         ─────────────────────
01 Phonics                  06 Present Simple              11 Conversation
02 Spelling                 07 Present Continuous          12 Reading
03 Sight Words               08 Past Simple                 13 Error Detection
04 Vocabulary                09 Future Tense                14 Grammar Summary
05 Parts of Speech           10 WH-Questions                15 Entrance Exam
```

**หลักการเรียงลำดับ:** ต้องอ่านออกเสียงได้ก่อน (01-03) → มีคลังคำศัพท์และรู้จัก
ชนิดคำ (04-05) → เรียนโครงสร้างประโยค/Tense (06-10) → นำไปใช้จริงและฝึกทำข้อสอบ
(11-15) — ลำดับนี้ตรงกับลำดับหัวข้อในเมนู sidebar ของเว็บไซต์ และปุ่ม
Previous/Next จะพาไล่ตามลำดับนี้ทั้งหมด

## รายละเอียดแต่ละบท

| # | บท | เป้าหมายหลัก | สถานะเนื้อหา |
|---|---|---|---|
| 01 | [Phonics](./01-Phonics/) | อ่านออกเสียงตัวอักษร A-Z, พยัญชนะ, สระสั้น/ยาว/ผสม | ✅ เสร็จแล้ว — 9 หัวข้อย่อย แต่ละหัวข้อมีครบ 6 องค์ประกอบ (อธิบาย/ตัวอย่าง/แบบฝึกหัด/เฉลย/เทคนิคจำ/ข้อผิดพลาดที่พบบ่อย) |
| 02 | [Spelling](./02-Spelling/02-spelling.md) | กฎการสะกดคำพื้นฐาน, plural, -ing/-ed | ✅ เสร็จแล้ว |
| 03 | [Sight Words](./03-Sight-Words/03-sight-words.md) | คำศัพท์พบบ่อยที่ต้องอ่านได้ทันทีโดยไม่สะกด | ✅ เสร็จแล้ว |
| 04 | [Vocabulary](./04-Vocabulary/04-vocabulary.md) | คำศัพท์จำเป็นตามหมวด (ครอบครัว, โรงเรียน, เวลา ฯลฯ) | ✅ เสร็จแล้ว |
| 05 | [Parts of Speech](./05-Parts-of-Speech/05-parts-of-speech.md) | Noun, Verb, Adjective, Adverb, Pronoun, Preposition | ✅ เสร็จแล้ว |
| 06 | [Present Simple](./06-Present-Simple/06-present-simple.md) | โครงสร้าง + การใช้ Present Simple | ✅ เสร็จแล้ว |
| 07 | [Present Continuous](./07-Present-Continuous/07-present-continuous.md) | โครงสร้าง + เทียบกับ Present Simple | ✅ เสร็จแล้ว |
| 08 | [Past Simple](./08-Past-Simple/08-past-simple.md) | Regular/Irregular verbs, การใช้ | ✅ เสร็จแล้ว |
| 09 | [Future Tense](./09-Future-Tense/09-future-tense.md) | will / going to | ✅ เสร็จแล้ว |
| 10 | [WH-Questions](./10-WH-Questions/10-wh-questions.md) | What/Where/When/Who/Why/How | ✅ เสร็จแล้ว |
| 11 | [Conversation](./11-Conversation/11-conversation.md) | บทสนทนาในชีวิตประจำวัน | ✅ เสร็จแล้ว |
| 12 | [Reading](./12-Reading/12-reading.md) | อ่านจับใจความ, เดาความหมายจากบริบท | ✅ เสร็จแล้ว |
| 13 | [Error Detection](./13-Error-Detection/13-error-detection.md) | จับผิดประโยค (แนวข้อสอบ) | ✅ เสร็จแล้ว |
| 14 | [Grammar Summary](./14-Grammar-Summary/14-grammar-summary.md) | สรุปแกรมม่าทั้งหมดรวมเล่ม | ✅ เสร็จแล้ว |
| 15 | [Entrance Exam](./15-Entrance-Exam/15-entrance-exam.md) | ข้อสอบจำลองรวมทุกทักษะ (35 ข้อ + Speed Round 15 ข้อ) | ✅ เสร็จแล้ว |

## แผนการสอน (ตัวอย่าง ถ้าเรียน 1 บท/สัปดาห์)

| สัปดาห์ | บทเรียน | หมายเหตุ |
|---|---|---|
| 1 | 01 Phonics | ใช้เวลานานกว่าบทอื่นได้ เพราะเป็นฐานราก (9 หัวข้อย่อย อาจใช้ 2-3 สัปดาห์) |
| 2 | 02 Spelling | ต่อยอดจาก Phonics ทันที |
| 3 | 03 Sight Words | ทบทวน Phonics คู่กันไป |
| 4 | 04 Vocabulary | เริ่มสร้างคลังคำศัพท์ |
| 5 | 05 Parts of Speech | จำเป็นก่อนเข้า Tense |
| 6 | 06 Present Simple | Tense แรก เน้นให้แม่นก่อนไปต่อ |
| 7 | 07 Present Continuous | เทียบกับบทก่อนหน้าเสมอ |
| 8 | 08 Past Simple | เพิ่ม irregular verbs ทีละน้อย |
| 9 | 09 Future Tense | will vs going to |
| 10 | 10 WH-Questions | เชื่อมกับทุก Tense ที่เรียนมา |
| 11 | 11 Conversation | นำ Tense + WH-Question มาใช้จริง |
| 12 | 12 Reading | เริ่มอ่านย่อหน้าสั้น ๆ |
| 13 | 13 Error Detection | แนวข้อสอบเข้า ม.4 โดยตรง |
| 14 | 14 Grammar Summary | ทบทวนรวมก่อนสอบ |
| 15 | 15 Entrance Exam | จำลองสอบจริง จับเวลา |

## โครงสร้างเนื้อหาที่ใช้จริง

- **บทที่ 1 (Phonics):** 9 ไฟล์ .md แยกตามหัวข้อย่อย แต่ละไฟล์มีครบ 6 องค์ประกอบ
  (อธิบายภาษาไทย, ตัวอย่าง, แบบฝึกหัด, เฉลย, เทคนิคจำ, ข้อผิดพลาดที่เด็กไทยพบบ่อย)
- **บทที่ 2-15:** 1 ไฟล์ .md ต่อบท ครบ 8 องค์ประกอบ (อธิบายภาษาไทย, ตัวอย่าง,
  ตารางสรุป, Mind Map, Infographic, แบบฝึกหัด+เฉลย, Quiz+เฉลย, Flashcards)
- ทุกบทถูกประกอบเป็นเว็บไซต์เดียว ผ่าน `tools/build-site.js` ที่อ่านรายการจาก
  `tools/course-manifest.json` — ดูวิธี build ใหม่ได้ที่ [`README.md`](./README.md)

> หมายเหตุ: ไฟล์ `00-Templates/CHAPTER-TEMPLATE.md` เป็นแม่แบบเวอร์ชันแรกสุด
> ของโปรเจกต์ (ใช้ตอนวางแผนเริ่มต้น) ปัจจุบันเนื้อหาจริงใช้โครงสร้าง 6/8
> องค์ประกอบข้างต้นแทน ไม่ตรงกับไฟล์ template เดิมทุกประการ

⬅️ [กลับไปหน้าหลัก README](./README.md)
